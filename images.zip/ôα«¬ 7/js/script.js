$(document).ready(function(){
	$('.carousele').slick({
		arrows: true,
		autoplay: true,
		dots: true
	});
});